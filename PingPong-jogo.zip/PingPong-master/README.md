# PingPong
C# ping pong game ... with few chaneges


First .... You enter the number of points you are playing to win, then hit "Play" to start the game.



![p1](https://user-images.githubusercontent.com/22651469/39402380-b766c908-4b2b-11e8-9e42-e808b88471eb.jpg)




Second .... The game starts between 2 players, the player on the right can move the pedal using ( the arrow keys ), while the player on the left can use (W A S D) to move the pedal.
There are obsticales on the way of the ball standing between the two sides. Also theres a dotted line in the middle of the ground which respresents the net.




![p2](https://user-images.githubusercontent.com/22651469/39402379-b756deee-4b2b-11e8-8abd-dc9c73a57297.jpg)
